import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../431f971e-4eee-4691-aa03-d541f0ac3c76/src/item"
import Script2 from "../c44b9c20-02ab-4974-97e0-78e98ac722f0/src/item"
import Script3 from "../a491051c-8092-4245-ae85-d274e90d8443/src/item"
import Script4 from "../c5bcfd25-77a5-4186-a1fc-3525a7130daa/src/item"
import Script5 from "../d6dea640-b953-48b9-bfb0-d750c5f43ba1/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const yellowMagicStone = new Entity('yellowMagicStone')
engine.addEntity(yellowMagicStone)
yellowMagicStone.setParent(_scene)
const transform2 = new Transform({
  position: new Vector3(4.5, 2.5, 21),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
yellowMagicStone.addComponentOrReplace(transform2)
const gltfShape = new GLTFShape("models/Crystal_05/Crystal_05.glb")
gltfShape.withCollisions = true
gltfShape.isPointerBlocker = true
gltfShape.visible = true
yellowMagicStone.addComponentOrReplace(gltfShape)

const wildChives = new Entity('wildChives')
engine.addEntity(wildChives)
wildChives.setParent(_scene)
const transform3 = new Transform({
  position: new Vector3(26.158798217773438, 3.708770179855492e-8, 8.811114311218262),
  rotation: new Quaternion(0, 0.09801710397005081, -1.1684546663559559e-8, -0.9951847195625305),
  scale: new Vector3(1, 1, 1)
})
wildChives.addComponentOrReplace(transform3)
const gltfShape2 = new GLTFShape("models/Vegetation_07/Vegetation_07.glb")
gltfShape2.withCollisions = true
gltfShape2.isPointerBlocker = true
gltfShape2.visible = true
wildChives.addComponentOrReplace(gltfShape2)

const wildChives3 = new Entity('wildChives3')
engine.addEntity(wildChives3)
wildChives3.setParent(_scene)
const transform4 = new Transform({
  position: new Vector3(21.943021774291992, 0.5, 9.501931190490723),
  rotation: new Quaternion(0, 0.09801710397005081, -1.1684546663559559e-8, -0.9951847195625305),
  scale: new Vector3(1, 1, 1)
})
wildChives3.addComponentOrReplace(transform4)
wildChives3.addComponentOrReplace(gltfShape2)

const voidTulip2 = new Entity('voidTulip2')
engine.addEntity(voidTulip2)
voidTulip2.setParent(_scene)
const transform5 = new Transform({
  position: new Vector3(25.771284103393555, 3.8408419555935325e-8, 13.322193145751953),
  rotation: new Quaternion(0, 0.09801710397005081, -1.1684546663559559e-8, -0.9951847195625305),
  scale: new Vector3(1, 1, 1)
})
voidTulip2.addComponentOrReplace(transform5)
const gltfShape3 = new GLTFShape("models/Bush_Fantasy_02/Bush_Fantasy_02.glb")
gltfShape3.withCollisions = true
gltfShape3.isPointerBlocker = true
gltfShape3.visible = true
voidTulip2.addComponentOrReplace(gltfShape3)

const voidTulip4 = new Entity('voidTulip4')
engine.addEntity(voidTulip4)
voidTulip4.setParent(_scene)
const transform6 = new Transform({
  position: new Vector3(22.04323387145996, 0, 11.561046600341797),
  rotation: new Quaternion(0, 0.09801710397005081, -1.1684546663559559e-8, -0.9951847195625305),
  scale: new Vector3(1, 1, 1)
})
voidTulip4.addComponentOrReplace(transform6)
voidTulip4.addComponentOrReplace(gltfShape3)

const qrDonationsBlackbo3 = new Entity('qrDonationsBlackbo3')
engine.addEntity(qrDonationsBlackbo3)
qrDonationsBlackbo3.setParent(_scene)
const transform7 = new Transform({
  position: new Vector3(37, 0.059423863887786865, 34),
  rotation: new Quaternion(1.2652842640813178e-14, 0.6343932747840881, -7.562556447737734e-8, 0.7730104923248291),
  scale: new Vector3(0.9999960660934448, 1, 0.9999960660934448)
})
qrDonationsBlackbo3.addComponentOrReplace(transform7)

const archwayOfNightmares = new Entity('archwayOfNightmares')
engine.addEntity(archwayOfNightmares)
archwayOfNightmares.setParent(_scene)
const transform8 = new Transform({
  position: new Vector3(25, 0.5, 3.5),
  rotation: new Quaternion(-5.837277581059123e-15, -1, 1.1920928244535389e-7, 0),
  scale: new Vector3(1, 1, 1)
})
archwayOfNightmares.addComponentOrReplace(transform8)
const gltfShape4 = new GLTFShape("models/ArchWay_01/ArchWay_01.glb")
gltfShape4.withCollisions = true
gltfShape4.isPointerBlocker = true
gltfShape4.visible = true
archwayOfNightmares.addComponentOrReplace(gltfShape4)

const verticalCircularPl = new Entity('verticalCircularPl')
engine.addEntity(verticalCircularPl)
verticalCircularPl.setParent(_scene)
const transform9 = new Transform({
  position: new Vector3(29.5, 0.1888747215270996, 13),
  rotation: new Quaternion(0.5889722108840942, -0.26614245772361755, 0.22081542015075684, 0.7304248809814453),
  scale: new Vector3(2.8703603744506836, 9.272201538085938, 0.11540986597537994)
})
verticalCircularPl.addComponentOrReplace(transform9)

const indicatorArrowGree = new Entity('indicatorArrowGree')
engine.addEntity(indicatorArrowGree)
indicatorArrowGree.setParent(_scene)
const transform10 = new Transform({
  position: new Vector3(30.745752334594727, 1.4903926849365234, 7.39219856262207),
  rotation: new Quaternion(0.03750954568386078, -0.3808407187461853, -0.09055600315332413, 0.9194308519363403),
  scale: new Vector3(1, 0.9999998807907104, 1)
})
indicatorArrowGree.addComponentOrReplace(transform10)

const purplePalm = new Entity('purplePalm')
engine.addEntity(purplePalm)
purplePalm.setParent(_scene)
const transform11 = new Transform({
  position: new Vector3(9, 0, 27),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3, 3, 3)
})
purplePalm.addComponentOrReplace(transform11)
const gltfShape5 = new GLTFShape("models/PlantSF_01/PlantSF_01.glb")
gltfShape5.withCollisions = true
gltfShape5.isPointerBlocker = true
gltfShape5.visible = true
purplePalm.addComponentOrReplace(gltfShape5)

const orangeTrumpetSucculent = new Entity('orangeTrumpetSucculent')
engine.addEntity(orangeTrumpetSucculent)
orangeTrumpetSucculent.setParent(_scene)
const transform12 = new Transform({
  position: new Vector3(9.5, 1, 15.5),
  rotation: new Quaternion(2.7149316018796384e-15, -0.3826833665370941, 4.5619415800501883e-8, 0.9238796234130859),
  scale: new Vector3(12.500015258789062, 12.5, 12.500015258789062)
})
orangeTrumpetSucculent.addComponentOrReplace(transform12)
const gltfShape6 = new GLTFShape("models/PlantSF_06/PlantSF_06.glb")
gltfShape6.withCollisions = true
gltfShape6.isPointerBlocker = true
gltfShape6.visible = true
orangeTrumpetSucculent.addComponentOrReplace(gltfShape6)

const longStraightVent = new Entity('longStraightVent')
engine.addEntity(longStraightVent)
longStraightVent.setParent(_scene)
const transform13 = new Transform({
  position: new Vector3(33.5, 2, 37),
  rotation: new Quaternion(0.5555702447891235, 1.2389863002226775e-7, 1.6557279991502583e-8, 0.8314696550369263),
  scale: new Vector3(6.3414692878723145, 7.198342800140381, 6.223095893859863)
})
longStraightVent.addComponentOrReplace(transform13)
const gltfShape7 = new GLTFShape("models/AirVent_Straight_Long_01/AirVent_Straight_Long_01.glb")
gltfShape7.withCollisions = true
gltfShape7.isPointerBlocker = true
gltfShape7.visible = true
longStraightVent.addComponentOrReplace(gltfShape7)

const horizontalPlatform = new Entity('horizontalPlatform')
engine.addEntity(horizontalPlatform)
horizontalPlatform.setParent(_scene)
const transform14 = new Transform({
  position: new Vector3(4.5, 0.5, 40),
  rotation: new Quaternion(5.372324467410529e-16, -0.7071068286895752, 8.429369557916289e-8, 0.7071068286895752),
  scale: new Vector3(1.000012755393982, 1, 1.000012755393982)
})
horizontalPlatform.addComponentOrReplace(transform14)

const straightTube = new Entity('straightTube')
engine.addEntity(straightTube)
straightTube.setParent(_scene)
const transform15 = new Transform({
  position: new Vector3(3.5, 4, 44),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(12.25, 3.5, -13.125)
})
straightTube.addComponentOrReplace(transform15)
const gltfShape8 = new GLTFShape("models/Tube_01/Tube_01.glb")
gltfShape8.withCollisions = true
gltfShape8.isPointerBlocker = true
gltfShape8.visible = true
straightTube.addComponentOrReplace(gltfShape8)

const yellowNeonTubeOff = new Entity('yellowNeonTubeOff')
engine.addEntity(yellowNeonTubeOff)
yellowNeonTubeOff.setParent(_scene)
const transform16 = new Transform({
  position: new Vector3(4.5, 7.5, 44),
  rotation: new Quaternion(0, 0, 0.7071068286895752, 0.7071068286895752),
  scale: new Vector3(3.535090923309326, 20.02035903930664, 20.999998092651367)
})
yellowNeonTubeOff.addComponentOrReplace(transform16)
const gltfShape9 = new GLTFShape("models/NeonLightTube_01/NeonLightTube_01.glb")
gltfShape9.withCollisions = true
gltfShape9.isPointerBlocker = true
gltfShape9.visible = true
yellowNeonTubeOff.addComponentOrReplace(gltfShape9)

const nft = new Entity('nft')
engine.addEntity(nft)
nft.setParent(_scene)
const transform17 = new Transform({
  position: new Vector3(30.228759765625, 1.5, 38.25),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
nft.addComponentOrReplace(transform17)
const nftShape = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897900")
nftShape.withCollisions = true
nftShape.isPointerBlocker = true
nftShape.visible = true
nftShape.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft.addComponentOrReplace(nftShape)

const nft3 = new Entity('nft3')
engine.addEntity(nft3)
nft3.setParent(_scene)
const transform18 = new Transform({
  position: new Vector3(33.088134765625, 1.5, 39),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
nft3.addComponentOrReplace(transform18)
const nftShape2 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897898")
nftShape2.withCollisions = true
nftShape2.isPointerBlocker = true
nftShape2.visible = true
nftShape2.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft3.addComponentOrReplace(nftShape2)

const nft12 = new Entity('nft12')
engine.addEntity(nft12)
nft12.setParent(_scene)
const transform19 = new Transform({
  position: new Vector3(17.5, 1.5, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nft12.addComponentOrReplace(transform19)
const nftShape3 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897902")
nftShape3.withCollisions = true
nftShape3.isPointerBlocker = true
nftShape3.visible = true
nftShape3.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft12.addComponentOrReplace(nftShape3)

const nft13 = new Entity('nft13')
engine.addEntity(nft13)
nft13.setParent(_scene)
const transform20 = new Transform({
  position: new Vector3(22.459228515625, 1.5, 38.25),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
nft13.addComponentOrReplace(transform20)
const nftShape4 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897920")
nftShape4.withCollisions = true
nftShape4.isPointerBlocker = true
nftShape4.visible = true
nftShape4.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft13.addComponentOrReplace(nftShape4)

const nft15 = new Entity('nft15')
engine.addEntity(nft15)
nft15.setParent(_scene)
const transform21 = new Transform({
  position: new Vector3(17.5, 1.5, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nft15.addComponentOrReplace(transform21)
const nftShape5 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897909")
nftShape5.withCollisions = true
nftShape5.isPointerBlocker = true
nftShape5.visible = true
nftShape5.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft15.addComponentOrReplace(nftShape5)

const nft18 = new Entity('nft18')
engine.addEntity(nft18)
nft18.setParent(_scene)
const transform22 = new Transform({
  position: new Vector3(26.549072265625, 1.5, 39),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
nft18.addComponentOrReplace(transform22)
const nftShape6 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897925")
nftShape6.withCollisions = true
nftShape6.isPointerBlocker = true
nftShape6.visible = true
nftShape6.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft18.addComponentOrReplace(nftShape6)

const nft22 = new Entity('nft22')
engine.addEntity(nft22)
nft22.setParent(_scene)
const transform23 = new Transform({
  position: new Vector3(17.5, 1.5, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nft22.addComponentOrReplace(transform23)
const nftShape7 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897917")
nftShape7.withCollisions = true
nftShape7.isPointerBlocker = true
nftShape7.visible = true
nftShape7.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft22.addComponentOrReplace(nftShape7)

const nft23 = new Entity('nft23')
engine.addEntity(nft23)
nft23.setParent(_scene)
const transform24 = new Transform({
  position: new Vector3(18.914306640625, 1.5, 38.25),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
nft23.addComponentOrReplace(transform24)
const nftShape8 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897910")
nftShape8.withCollisions = true
nftShape8.isPointerBlocker = true
nftShape8.visible = true
nftShape8.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft23.addComponentOrReplace(nftShape8)

const nft24 = new Entity('nft24')
engine.addEntity(nft24)
nft24.setParent(_scene)
const transform25 = new Transform({
  position: new Vector3(38.806884765625, 1.5, 41.109375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5, 1.5, 1.5)
})
nft24.addComponentOrReplace(transform25)
const nftShape9 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897911")
nftShape9.withCollisions = true
nftShape9.isPointerBlocker = true
nftShape9.visible = true
nftShape9.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft24.addComponentOrReplace(nftShape9)

const nft25 = new Entity('nft25')
engine.addEntity(nft25)
nft25.setParent(_scene)
const transform26 = new Transform({
  position: new Vector3(17.5, 1.5, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nft25.addComponentOrReplace(transform26)
const nftShape10 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897908")
nftShape10.withCollisions = true
nftShape10.isPointerBlocker = true
nftShape10.visible = true
nftShape10.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft25.addComponentOrReplace(nftShape10)

const nft26 = new Entity('nft26')
engine.addEntity(nft26)
nft26.setParent(_scene)
const transform27 = new Transform({
  position: new Vector3(17.5, 1.5, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nft26.addComponentOrReplace(transform27)
const nftShape11 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897903")
nftShape11.withCollisions = true
nftShape11.isPointerBlocker = true
nftShape11.visible = true
nftShape11.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft26.addComponentOrReplace(nftShape11)

const nft27 = new Entity('nft27')
engine.addEntity(nft27)
nft27.setParent(_scene)
const transform28 = new Transform({
  position: new Vector3(17.5, 1.5, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nft27.addComponentOrReplace(transform28)
const nftShape12 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897897")
nftShape12.withCollisions = true
nftShape12.isPointerBlocker = true
nftShape12.visible = true
nftShape12.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft27.addComponentOrReplace(nftShape12)

const nft28 = new Entity('nft28')
engine.addEntity(nft28)
nft28.setParent(_scene)
const transform29 = new Transform({
  position: new Vector3(17.5, 1.5, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
nft28.addComponentOrReplace(transform29)
const nftShape13 = new NFTShape("ethereum://0x0e3a2a1f2146d86a604adc220b4967a898d7fe07/34897924")
nftShape13.withCollisions = true
nftShape13.isPointerBlocker = true
nftShape13.visible = true
nftShape13.color = {"r":0.6404918,"g":0.611472,"b":0.8584906}
nft28.addComponentOrReplace(nftShape13)

const goldenChestBase = new Entity('goldenChestBase')
engine.addEntity(goldenChestBase)
goldenChestBase.setParent(_scene)
const transform30 = new Transform({
  position: new Vector3(37, 0, 36),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
goldenChestBase.addComponentOrReplace(transform30)
const gltfShape10 = new GLTFShape("models/Chest_Base_Gold_01/Chest_Base_Gold_01.glb")
gltfShape10.withCollisions = true
gltfShape10.isPointerBlocker = true
gltfShape10.visible = true
goldenChestBase.addComponentOrReplace(gltfShape10)

const goldenChestLid = new Entity('goldenChestLid')
engine.addEntity(goldenChestLid)
goldenChestLid.setParent(_scene)
const transform31 = new Transform({
  position: new Vector3(37.5, 1, 31.5),
  rotation: new Quaternion(0.9569404125213623, 2.7792730715860223e-15, -1.1407617961367578e-7, 0.2902846932411194),
  scale: new Vector3(1, 1.0000174045562744, 1.0000174045562744)
})
goldenChestLid.addComponentOrReplace(transform31)
const gltfShape11 = new GLTFShape("models/Chest_Top_Gold_01/Chest_Top_Gold_01.glb")
gltfShape11.withCollisions = true
gltfShape11.isPointerBlocker = true
gltfShape11.visible = true
goldenChestLid.addComponentOrReplace(gltfShape11)

const goldenOinochoe = new Entity('goldenOinochoe')
engine.addEntity(goldenOinochoe)
goldenOinochoe.setParent(_scene)
const transform32 = new Transform({
  position: new Vector3(36.5, 0, 35),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
goldenOinochoe.addComponentOrReplace(transform32)
const gltfShape12 = new GLTFShape("models/Vase_04/Vase_04.glb")
gltfShape12.withCollisions = true
gltfShape12.isPointerBlocker = true
gltfShape12.visible = true
goldenOinochoe.addComponentOrReplace(gltfShape12)

const goldenLekythos = new Entity('goldenLekythos')
engine.addEntity(goldenLekythos)
goldenLekythos.setParent(_scene)
const transform33 = new Transform({
  position: new Vector3(37.5, 0, 33.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
goldenLekythos.addComponentOrReplace(transform33)
const gltfShape13 = new GLTFShape("models/Vase_05/Vase_05.glb")
gltfShape13.withCollisions = true
gltfShape13.isPointerBlocker = true
gltfShape13.visible = true
goldenLekythos.addComponentOrReplace(gltfShape13)

const goldenLekythos2 = new Entity('goldenLekythos2')
engine.addEntity(goldenLekythos2)
goldenLekythos2.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(38, 0.16113948822021484, 36),
  rotation: new Quaternion(-0.1866898238658905, 0.05663174390792847, 0.2847070097923279, 0.9385530352592468),
  scale: new Vector3(1, 0.9999998807907104, 1)
})
goldenLekythos2.addComponentOrReplace(transform34)
goldenLekythos2.addComponentOrReplace(gltfShape13)

const greenPotion = new Entity('greenPotion')
engine.addEntity(greenPotion)
greenPotion.setParent(_scene)
const transform35 = new Transform({
  position: new Vector3(37, 0.06063133478164673, 35),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
greenPotion.addComponentOrReplace(transform35)
const gltfShape14 = new GLTFShape("models/Potion_03/Potion_03.glb")
gltfShape14.withCollisions = true
gltfShape14.isPointerBlocker = true
gltfShape14.visible = true
greenPotion.addComponentOrReplace(gltfShape14)

const goldenWallOrnament = new Entity('goldenWallOrnament')
engine.addEntity(goldenWallOrnament)
goldenWallOrnament.setParent(_scene)
const transform36 = new Transform({
  position: new Vector3(37, 2, 35),
  rotation: new Quaternion(0.6501357555389404, 0.3386034369468689, -0.6501359343528748, -0.19998611509799957),
  scale: new Vector3(1.0000016689300537, 1.0000009536743164, 1.0000019073486328)
})
goldenWallOrnament.addComponentOrReplace(transform36)
const gltfShape15 = new GLTFShape("models/Ornament_01/Ornament_01.glb")
gltfShape15.withCollisions = true
gltfShape15.isPointerBlocker = true
gltfShape15.visible = true
goldenWallOrnament.addComponentOrReplace(gltfShape15)

const gemstoneOrnament = new Entity('gemstoneOrnament')
engine.addEntity(gemstoneOrnament)
gemstoneOrnament.setParent(_scene)
const transform37 = new Transform({
  position: new Vector3(37.5, 0, 32.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
gemstoneOrnament.addComponentOrReplace(transform37)
const gltfShape16 = new GLTFShape("models/Ornament_Stone_01/Ornament_Stone_01.glb")
gltfShape16.withCollisions = true
gltfShape16.isPointerBlocker = true
gltfShape16.visible = true
gemstoneOrnament.addComponentOrReplace(gltfShape16)

const gemstoneOrnament2 = new Entity('gemstoneOrnament2')
engine.addEntity(gemstoneOrnament2)
gemstoneOrnament2.setParent(_scene)
const transform38 = new Transform({
  position: new Vector3(36, 0, 36),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
gemstoneOrnament2.addComponentOrReplace(transform38)
gemstoneOrnament2.addComponentOrReplace(gltfShape16)

const goldenChestBase2 = new Entity('goldenChestBase2')
engine.addEntity(goldenChestBase2)
goldenChestBase2.setParent(_scene)
const transform39 = new Transform({
  position: new Vector3(37.5, 0.06620907783508301, 32.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
goldenChestBase2.addComponentOrReplace(transform39)
goldenChestBase2.addComponentOrReplace(gltfShape10)

const goldenLekythos3 = new Entity('goldenLekythos3')
engine.addEntity(goldenLekythos3)
goldenLekythos3.setParent(_scene)
const transform40 = new Transform({
  position: new Vector3(37, 0, 35.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
goldenLekythos3.addComponentOrReplace(transform40)
goldenLekythos3.addComponentOrReplace(gltfShape13)

const blueAcaciaTree = new Entity('blueAcaciaTree')
engine.addEntity(blueAcaciaTree)
blueAcaciaTree.setParent(_scene)
const transform41 = new Transform({
  position: new Vector3(34.5, 0.5, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
blueAcaciaTree.addComponentOrReplace(transform41)
const gltfShape17 = new GLTFShape("models/Tree_Forest_Blue_01/Tree_Forest_Blue_01.glb")
gltfShape17.withCollisions = true
gltfShape17.isPointerBlocker = true
gltfShape17.visible = true
blueAcaciaTree.addComponentOrReplace(gltfShape17)

const bluePinkMysticalMushroomTree2 = new Entity('bluePinkMysticalMushroomTree2')
engine.addEntity(bluePinkMysticalMushroomTree2)
bluePinkMysticalMushroomTree2.setParent(_scene)
const transform42 = new Transform({
  position: new Vector3(22, 0.5, 28.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bluePinkMysticalMushroomTree2.addComponentOrReplace(transform42)
const gltfShape18 = new GLTFShape("models/Tree_02/Tree_02.glb")
gltfShape18.withCollisions = true
gltfShape18.isPointerBlocker = true
gltfShape18.visible = true
bluePinkMysticalMushroomTree2.addComponentOrReplace(gltfShape18)

const bluePinkMysticalMushroomTree3 = new Entity('bluePinkMysticalMushroomTree3')
engine.addEntity(bluePinkMysticalMushroomTree3)
bluePinkMysticalMushroomTree3.setParent(_scene)
const transform43 = new Transform({
  position: new Vector3(16, 0.5, 34.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
bluePinkMysticalMushroomTree3.addComponentOrReplace(transform43)
bluePinkMysticalMushroomTree3.addComponentOrReplace(gltfShape18)

const cyanLeafShrub = new Entity('cyanLeafShrub')
engine.addEntity(cyanLeafShrub)
cyanLeafShrub.setParent(_scene)
const transform44 = new Transform({
  position: new Vector3(25.3809757232666, 0, 33.96773910522461),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
cyanLeafShrub.addComponentOrReplace(transform44)
const gltfShape19 = new GLTFShape("models/Vegetation_09/Vegetation_09.glb")
gltfShape19.withCollisions = true
gltfShape19.isPointerBlocker = true
gltfShape19.visible = true
cyanLeafShrub.addComponentOrReplace(gltfShape19)

const dracaena = new Entity('dracaena')
engine.addEntity(dracaena)
dracaena.setParent(_scene)
const transform45 = new Transform({
  position: new Vector3(27.5, 0, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
dracaena.addComponentOrReplace(transform45)
const gltfShape20 = new GLTFShape("models/Vegetation_02/Vegetation_02.glb")
gltfShape20.withCollisions = true
gltfShape20.isPointerBlocker = true
gltfShape20.visible = true
dracaena.addComponentOrReplace(gltfShape20)

const fatsia = new Entity('fatsia')
engine.addEntity(fatsia)
fatsia.setParent(_scene)
const transform46 = new Transform({
  position: new Vector3(27.5, 0, 34),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fatsia.addComponentOrReplace(transform46)
const gltfShape21 = new GLTFShape("models/Vegetation_10/Vegetation_10.glb")
gltfShape21.withCollisions = true
gltfShape21.isPointerBlocker = true
gltfShape21.visible = true
fatsia.addComponentOrReplace(gltfShape21)

const fatsia2 = new Entity('fatsia2')
engine.addEntity(fatsia2)
fatsia2.setParent(_scene)
const transform47 = new Transform({
  position: new Vector3(31.5, 0, 16.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fatsia2.addComponentOrReplace(transform47)
fatsia2.addComponentOrReplace(gltfShape21)

const stoneBrickWall = new Entity('stoneBrickWall')
engine.addEntity(stoneBrickWall)
stoneBrickWall.setParent(_scene)
const transform48 = new Transform({
  position: new Vector3(47.47999572753906, 0.5, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.119628429412842, 1.5, 1.0000004768371582)
})
stoneBrickWall.addComponentOrReplace(transform48)
const gltfShape22 = new GLTFShape("models/Module_Stone_Straight_01/Module_Stone_Straight_01.glb")
gltfShape22.withCollisions = true
gltfShape22.isPointerBlocker = true
gltfShape22.visible = true
stoneBrickWall.addComponentOrReplace(gltfShape22)

const stoneBrickWall2 = new Entity('stoneBrickWall2')
engine.addEntity(stoneBrickWall2)
stoneBrickWall2.setParent(_scene)
const transform49 = new Transform({
  position: new Vector3(23, 0.5, 3),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(5.5, 1.5, 0.9999999403953552)
})
stoneBrickWall2.addComponentOrReplace(transform49)
stoneBrickWall2.addComponentOrReplace(gltfShape22)

const stoneBrickWall3 = new Entity('stoneBrickWall3')
engine.addEntity(stoneBrickWall3)
stoneBrickWall3.setParent(_scene)
stoneBrickWall3.addComponentOrReplace(gltfShape22)
const transform50 = new Transform({
  position: new Vector3(47, 0.5, 24.5),
  rotation: new Quaternion(2.262906752104987e-16, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(5.119640827178955, 1.5, 1.0000035762786865)
})
stoneBrickWall3.addComponentOrReplace(transform50)

const stoneBrickWall4 = new Entity('stoneBrickWall4')
engine.addEntity(stoneBrickWall4)
stoneBrickWall4.setParent(_scene)
stoneBrickWall4.addComponentOrReplace(gltfShape22)
const transform51 = new Transform({
  position: new Vector3(47, 0.5, 45),
  rotation: new Quaternion(2.262906752104987e-16, 0.7071068286895752, -8.429369557916289e-8, -0.7071068286895752),
  scale: new Vector3(5.119643688201904, 1.5, 1.0000042915344238)
})
stoneBrickWall4.addComponentOrReplace(transform51)

const wildLongMushrooms6 = new Entity('wildLongMushrooms6')
engine.addEntity(wildLongMushrooms6)
wildLongMushrooms6.setParent(_scene)
const transform52 = new Transform({
  position: new Vector3(27, 0, 31),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
wildLongMushrooms6.addComponentOrReplace(transform52)
const gltfShape23 = new GLTFShape("models/Mushrooms_04/Mushrooms_04.glb")
gltfShape23.withCollisions = true
gltfShape23.isPointerBlocker = true
gltfShape23.visible = true
wildLongMushrooms6.addComponentOrReplace(gltfShape23)

const wildLongMushrooms7 = new Entity('wildLongMushrooms7')
engine.addEntity(wildLongMushrooms7)
wildLongMushrooms7.setParent(_scene)
const transform53 = new Transform({
  position: new Vector3(27, 0, 31),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
wildLongMushrooms7.addComponentOrReplace(transform53)
wildLongMushrooms7.addComponentOrReplace(gltfShape23)

const wildLongMushrooms8 = new Entity('wildLongMushrooms8')
engine.addEntity(wildLongMushrooms8)
wildLongMushrooms8.setParent(_scene)
const transform54 = new Transform({
  position: new Vector3(27, 0, 31),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
wildLongMushrooms8.addComponentOrReplace(transform54)
wildLongMushrooms8.addComponentOrReplace(gltfShape23)

const musaAcuminata2 = new Entity('musaAcuminata2')
engine.addEntity(musaAcuminata2)
musaAcuminata2.setParent(_scene)
const transform55 = new Transform({
  position: new Vector3(32, 0, 14),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
musaAcuminata2.addComponentOrReplace(transform55)
const gltfShape24 = new GLTFShape("models/JunglePlant_04/JunglePlant_04.glb")
gltfShape24.withCollisions = true
gltfShape24.isPointerBlocker = true
gltfShape24.visible = true
musaAcuminata2.addComponentOrReplace(gltfShape24)

const parrot = new Entity('parrot')
engine.addEntity(parrot)
parrot.setParent(_scene)
const transform56 = new Transform({
  position: new Vector3(24.5, 5.5, 3.499999523162842),
  rotation: new Quaternion(8.329572078467126e-15, 0.9807853102684021, -1.1691871293351142e-7, 0.19509033858776093),
  scale: new Vector3(1.000002384185791, 1, 1.000002384185791)
})
parrot.addComponentOrReplace(transform56)

const beachRock3 = new Entity('beachRock3')
engine.addEntity(beachRock3)
beachRock3.setParent(_scene)
const transform57 = new Transform({
  position: new Vector3(16.5, 1.5, 12.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
beachRock3.addComponentOrReplace(transform57)
const gltfShape25 = new GLTFShape("models/RockBig_01/RockBig_01.glb")
gltfShape25.withCollisions = true
gltfShape25.isPointerBlocker = true
gltfShape25.visible = true
beachRock3.addComponentOrReplace(gltfShape25)

const beachRock4 = new Entity('beachRock4')
engine.addEntity(beachRock4)
beachRock4.setParent(_scene)
const transform58 = new Transform({
  position: new Vector3(5, 1, 24.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
beachRock4.addComponentOrReplace(transform58)
const gltfShape26 = new GLTFShape("models/RockBig_02/RockBig_02.glb")
gltfShape26.withCollisions = true
gltfShape26.isPointerBlocker = true
gltfShape26.visible = true
beachRock4.addComponentOrReplace(gltfShape26)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape27 = new GLTFShape("models/FloorBaseSand_01/FloorBaseSand_01.glb")
gltfShape27.withCollisions = true
gltfShape27.isPointerBlocker = true
gltfShape27.visible = true
entity.addComponentOrReplace(gltfShape27)
const transform59 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform59)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape27)
const transform60 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform60)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape27)
const transform61 = new Transform({
  position: new Vector3(40, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform61)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape27)
const transform62 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform62)

const entity5 = new Entity('entity5')
engine.addEntity(entity5)
entity5.setParent(_scene)
entity5.addComponentOrReplace(gltfShape27)
const transform63 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity5.addComponentOrReplace(transform63)

const entity6 = new Entity('entity6')
engine.addEntity(entity6)
entity6.setParent(_scene)
entity6.addComponentOrReplace(gltfShape27)
const transform64 = new Transform({
  position: new Vector3(40, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity6.addComponentOrReplace(transform64)

const entity7 = new Entity('entity7')
engine.addEntity(entity7)
entity7.setParent(_scene)
entity7.addComponentOrReplace(gltfShape27)
const transform65 = new Transform({
  position: new Vector3(8, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity7.addComponentOrReplace(transform65)

const entity8 = new Entity('entity8')
engine.addEntity(entity8)
entity8.setParent(_scene)
entity8.addComponentOrReplace(gltfShape27)
const transform66 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity8.addComponentOrReplace(transform66)

const entity9 = new Entity('entity9')
engine.addEntity(entity9)
entity9.setParent(_scene)
entity9.addComponentOrReplace(gltfShape27)
const transform67 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity9.addComponentOrReplace(transform67)

const tnt = new Entity('tnt')
engine.addEntity(tnt)
tnt.setParent(_scene)
const transform68 = new Transform({
  position: new Vector3(3.5, 0, 44.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.3967854976654053, 3.5, 4.60752534866333)
})
tnt.addComponentOrReplace(transform68)
const gltfShape28 = new GLTFShape("models/tnt.glb")
gltfShape28.withCollisions = true
gltfShape28.isPointerBlocker = true
gltfShape28.visible = true
tnt.addComponentOrReplace(gltfShape28)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script1.spawn(qrDonationsBlackbo3, {"publicKey":"0xF7Cb3A050570C2BfC52f31843E28436571a245F1","text":"If you liked...\n Im very Happy  :)","fontSize":15}, createChannel(channelId, qrDonationsBlackbo3, channelBus))
script2.spawn(verticalCircularPl, {"distance":8,"speed":8,"autoStart":true,"onReachEnd":[{"entityName":"verticalCircularPl","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"verticalCircularPl","actionId":"goToEnd","values":{}}]}, createChannel(channelId, verticalCircularPl, channelBus))
script3.spawn(indicatorArrowGree, {"active":true}, createChannel(channelId, indicatorArrowGree, channelBus))
script4.spawn(horizontalPlatform, {"distance":31,"speed":2,"autoStart":true,"onReachEnd":[{"entityName":"horizontalPlatform","actionId":"goToStart","values":{}}],"onReachStart":[{"entityName":"horizontalPlatform","actionId":"goToEnd","values":{}}]}, createChannel(channelId, horizontalPlatform, channelBus))
script5.spawn(parrot, {"onActivate":[{"entityName":"qrDonationsBlackbo3","actionId":"changeText","values":{}}]}, createChannel(channelId, parrot, channelBus))